# AERIS — Smart Building AI Platform

This folder contains the full commented project files for GitHub.

## Files included

- `Agentic_Climate_Intelligence_Workflow_FULL_WITH_HUMANIZED_COMMENTS.json`
  - n8n workflow for the Agentic AI / Gemini-based prediction, anomaly, and recommendation pipeline.

- `LSTM_Forecasting_Workflow_FULL_WITH_HUMANIZED_COMMENTS.json`
  - n8n workflow for LSTM-based forecasting using trained weights.

- `Regression_Prediction_Workflow_FULL_WITH_HUMANIZED_COMMENTS.json`
  - n8n workflow for Ridge Regression prediction using time-based Fourier features.

- `AERIS_FULL_WITH_HUMANIZED_COMMENTS.html`
  - Frontend dashboard used to call the workflows and display prediction results.

## Important note

JSON does not support normal `// comments`, so comments were added safely inside:
- n8n Code node JavaScript strings
- n8n node notes
- top-level README notes

The workflows should remain valid JSON and importable into n8n.
